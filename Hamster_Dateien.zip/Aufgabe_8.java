import de.hamster.debugger.model.Territorium;import de.hamster.debugger.model.Territory;import de.hamster.model.HamsterException;import de.hamster.model.HamsterInitialisierungsException;import de.hamster.model.HamsterNichtInitialisiertException;import de.hamster.model.KachelLeerException;import de.hamster.model.MauerDaException;import de.hamster.model.MaulLeerException;import de.hamster.model.MouthEmptyException;import de.hamster.model.WallInFrontException;import de.hamster.model.TileEmptyException;public class Aufgabe_8 extends de.hamster.debugger.model.IHamster implements de.hamster.model.HamsterProgram {public void main() {
vor();
vorausgehen();
}

//Wenn ein Korn auf dem Feld ist soll das Korn aufgenommen werden und ein Schritt nach vorne gegangen werden.
//Wenn kein Korn auf dem Feld ist soll der Hamster sich um 180� drehen auf das vorherige Feld vor gehen.
//Auf dem Feld dreht der Hamster sich nach rechts. Wenn vor dem Hamster das Feld frei ist geht der Hamster vor.
//Wenn das Feld nicht frei ist dreht der Hamster sich nach links und geht ein Feld vor.
//Daraufhin geht der Hamster wieder einen schritt vor.
void Wegfrei(){
if(kornDa()){
	nimm();
	vor();
	}
	else{
		umdrehen();
		vor();
		rechtsUm();
		if(!vornFrei()){
			linksUm();
			vor();
		}
		else{
			vor();
		}
	}
}

//St�tige Ausf�hrung der Wegfindung. Wenn der Weg vor dem Hamster frei ist oder kein Korn auf dem Feld liegt.
void vorausgehen(){
do{
	Wegfrei();
}
	while(vornFrei() || !kornDa());
}

//Der Hamster dreht sich nach rechts.
void rechtsUm(){
umdrehen();
linksUm();
}

//Der Hamster dreht sich um 180�.
void umdrehen(){
linksUm();
linksUm();
}}